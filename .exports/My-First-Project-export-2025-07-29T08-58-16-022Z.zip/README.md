# My First Project

A sample project to get started with PLOT

## Export Information
- Exported on: 2025-07-29T08:58:16.128Z
- Language: javascript
- Includes: Project files

## Import Instructions
1. Create a new project in your IDE
2. Upload this archive using the import feature
3. 
4. Run the project

## Notes
- Secret environment variables are not included for security reasons
- Check .env.secrets for a list of required secret keys
